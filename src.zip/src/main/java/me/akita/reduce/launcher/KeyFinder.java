package me.akita.reduce.launcher;/*

@Author https://github.com/akita0
2023

*/
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.serialization.ClassResolvers;
import io.netty.handler.codec.serialization.ObjectDecoder;
import io.netty.handler.codec.serialization.ObjectEncoder;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.util.ResourceLeakDetector;

import java.net.InetAddress;
import java.util.ArrayList;

public class KeyFinder {
    public final String CRAFT_RISE_SESSION =  "185.255.92.10";
    public SocketChannel channel;
    public ArrayList<String> messages = new ArrayList<>();
    public void openConnection()
    {

        try {
            Bootstrap bootstrap = new Bootstrap();
            ResourceLeakDetector.setLevel(ResourceLeakDetector.Level.DISABLED);
            bootstrap.group(new NioEventLoopGroup())
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel socketChannel) throws Exception {
                            channel = socketChannel;
                            ChannelPipeline pipeline = socketChannel.pipeline();
                            pipeline.addLast(new ObjectDecoder(ClassResolvers.softCachingResolver(ClassLoader.getSystemClassLoader())));
                            pipeline.addLast(new ObjectEncoder());
                            SimpleChannelInboundHandler<Object> handler = new SimpleChannelInboundHandler<Object>() {
                                @Override
                                protected void channelRead0(ChannelHandlerContext var1_1, Object var2_2) {
                                    messages.add(var2_2.toString());
                                }
                            };
                            pipeline.addLast(handler);
                        }


                    }).option(ChannelOption.SO_KEEPALIVE, true).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 8000);
                ChannelFuture channel = bootstrap.connect("185.255.92.10", 4754).sync();
                channel.addListener(new ChannelFutureListener() {
                    @Override
                    public void operationComplete(ChannelFuture channelFuture) throws Exception {
                        System.out.println("Connected to 185.255.92.10 (real)!");
                        channelFuture.channel().closeFuture();
                    }
                });
                new Thread(() -> {
                    while(true)
                    {
                        channel.channel().writeAndFlush("{\"messageType\":\"alive\"}");
                        try {
                            Thread.sleep(7000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }).start();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void getSessions(String user , String pass)
    {
        {
            channel.writeAndFlush("{\"messageType\":\"trySplashLogin\",\"datas\":{\"sumBigX\":\"83733c6d1380014dda7260e40bec80d7\",\"password\":\""+pass+"\",\"sumBig\":\"50b15a2bcbd6a6a9937b83d80338c2f2\",\"sumBigY\":\"40aef9502c009ab5e7e0df67f8864c89\",\"sum\":\"a8408a57ab34cf8901cc1a26b4582865\",\"key\":\"VXRoWHJLY0RGL2Q0dDlmQUN3b3puYkRPTGxIdzY3T3Nua2VsVDZKUkFlcW5KaGlxTVAxeEVRZzNpSERDVTdOQnZieDFqRWVydk16Uk0zbW50ZGFWSzJJcHo1V0ozbkJ1NmxZSHBOazlBcUZBWjJ1cUdBSFRhdENmaExPanJzRjY4T1YvYTJjRHdSMWltU0RLRWhuaE5hRy9tR2xETlA4MzAwY2VORFZUY09CU0tzakg0MXhtdTZNT1BaOGt6WExx\",\"username\":\""+user+"\",\"staticSessionKey\":\"baba\"}}");
        }
    }
    public void printRacVerifier()
    {
        channel.writeAndFlush("{\"HYgfch2S5JNV7jpCPSajCDQ9MVTGh3\":\"mNACfVcxATyj36Jw6meapTIERy3t4c4rGnbkgQiSDi1QBsvbfopgscMK8QZvtiIlDi3hCMOdp2wdSqsCmufeuHpdN+6tIa4hvsMZL5Q08py29tSb\\/6\\/5G2KWtCNU4OAOevkqhwJZJfb4xP3rAxjYw+BacI8TXGJY+W4nV6tKw0Kz+qeFjHAQSSlbDVs61aWwQMO1n1bp0F2WeXX00XMd3N8IF5UDgc1oqm1v1j4YreK1hwGAHV+Car+a6VH6Bh9F1uQ7BHOm06v0\\/lBevSJYscQOaGzL+HLVti7NI34acdQbsnTcIUiH57oJO2NKk42cgpIJAc4rbhe5XgrnlbAXGA==\",\"mMk4tp8MuM347vUySepCXY9W6ayizq\":\"Allah123\",\"msgType\":\"racPacket\",\"3tgHB7eM8GLUm2kq4HLvaKiPJHCXX8\":1647198751,\"9ZTbREyB93BuWWiZeRy5ruVJ8CBTJy\":90,\"hk4Y7xSnGNRiBVX5iJyTWHdr4N29tb\":\"k+ultUotwiTwk7klfnVuBIzDI2uDB0Kuher67Z5WVPIcI1n6vD1fWxm+k3pEzy4vFFzXfB9Vlgk1iSIGXZX85znLxlw5n61cLC+EeYINNNT2OtU0THgWjw17Jj3OAGWBmU0kYvuqPh1Pf1POZgEv6qGbkR18NmcJhSRvcok465vBujlvgD4xDY29uDZqTJWAzJWIvVT0s8IhbV4ViMxwavU\\/t6JZqwMi52kr61wJnqSg8KkGcnRSyrCc\\/zsx56HdfRLKSnECKTRGfiB8cKKiYOs+yl8Tza3O3ooAyR4ai9CrQE8DJFG3eO5Bf+aC+q+KjwOSH+wj8TXomcLUutSAlw==\",\"zHJqKEd7ydL6rEYYnP8a7AwHdj8DHb\":\"H+7laAJOJ0RXdFSMxSpdJ0Wr2qZPE77Pr+gLWQq5qQC8Wc\\/e1qSMmAcHW7EvkoU6eGIeQDw1dsew+eL\\/SJcRoyfC1yVXKrotuPnf+En0gg0d23wSY4DVvL+jX\\/rMPN\\/vzD2U12zM8Hp4xFvg94u8gFwX\\/6HzXzhphQnKvWycJZVQOmlPTffT5BVbxssNErCCBK47Hj0LcQgrTSjt52Y0hba4y8bemrSqqYRZ+mLOsp\\/zLjg89yguRPEg8L9YO\\/iyXdnBK8tdMLhw\\/2lV7w9TaW4NwCM5CrYTHODG6QgMwGBkVmKlw\\/LZ2O8ojFPDctlOLo1GU7FlVCV7Kkdm255eJg==\",\"jq0jY9VzHkPgTYr7DP98DGjJRuUi4g\":\"SZZUZUU\",\"nHWZWHU6fWiJpwHryWTitWT9kRRqtB\":90,\"9bHCtNd5qzzWewWrAJYwk24\":\"\",\"JTBKb9Kmrpip7Gn7rnzctgiHBhFBzf\":\"iMayori\",\"bn24nCUN4Jweu7pcF774xGKHRZdRAw\":\"O1cWaD\\/ooGQntpLXq8Lx3hdvH3unmGI9h25oJYbLCNbZCNp+PBHFbj8T\\/JZ8Wajpgq6pkQnT3V2kRbLRPPzKqi5j72rtQKiuNQa+2aM9yQ7JC95IhXE8vTKXeVygml+tFS4KjbA5y5ChboxLJUe5PhkemFjKvDru0bZFxiyrBzObzM75LX0gWp1rqiiBZopPvoerJn28YitjZpGB7j5CoDDhThtYrux+BiyzJ8YDh07P8s9rjjN9L10YIU1kgla1+RbJsmkh7Q3ToDcomF2+QJJtnB5i4k4\\/anWYJxPGlllKox8QN9eH56VR4BDkKB0NrxVBGYJbSc8CZ0s+OEWlMg==\"}");
    }
}
