package me.akita.reduce.launcher;

/**
 * ----------
 * 10/7/2023
 * 4:23 PM
 * ----------
 **/
public class SplashLoginObject {
    private String globalSessionHash;
    private String password;
    private String messageType;
    private String skinURL;
    private float playerRankId;
    private String keyValidator;
    private String staticSessionKey;
    private String status;
    private String username;


    // Getter Methods

    public String getGlobalSessionHash() {
        return globalSessionHash;
    }

    public String getPassword() {
        return password;
    }

    public String getMessageType() {
        return messageType;
    }

    public String getSkinURL() {
        return skinURL;
    }

    public float getPlayerRankId() {
        return playerRankId;
    }

    public String getKeyValidator() {
        return keyValidator;
    }

    public String getStaticSessionKey() {
        return staticSessionKey;
    }

    public String getStatus() {
        return status;
    }

    public String getUsername() {
        return username;
    }

    // Setter Methods

    public void setGlobalSessionHash(String globalSessionHash) {
        this.globalSessionHash = globalSessionHash;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public void setSkinURL(String skinURL) {
        this.skinURL = skinURL;
    }

    public void setPlayerRankId(float playerRankId) {
        this.playerRankId = playerRankId;
    }

    public void setKeyValidator(String keyValidator) {
        this.keyValidator = keyValidator;
    }

    public void setStaticSessionKey(String staticSessionKey) {
        this.staticSessionKey = staticSessionKey;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
