package me.akita.reduce;

import com.google.gson.Gson;
import com.sun.tools.attach.VirtualMachine;
import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.tree.ClassNode;
import me.akita.reduce.craftrise.CraftRiseCrypto;
import me.akita.reduce.craftrise.CraftRiseSession;
import me.akita.reduce.craftrise.CraftRiseSessionArg;
import me.akita.reduce.craftrise.RiseLauncher;
import me.akita.reduce.launcher.KeyFinder;
import me.akita.reduce.launcher.SplashLoginObject;
import sun.jvmstat.monitor.MonitoredHost;
import sun.jvmstat.monitor.MonitoredVm;
import sun.jvmstat.monitor.MonitoredVmUtil;
import sun.jvmstat.monitor.VmIdentifier;

import javax.swing.*;
import java.io.*;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;


public class Main {
    public static void main(String[] a) throws Exception {
        RiseLauncher riseLauncher = new RiseLauncher("iMayori" , "Allah123");
        riseLauncher.launchRise();
    }
}
