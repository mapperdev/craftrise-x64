package me.akita.reduce.agent;

import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.Arrays;


public class Transformer implements ClassFileTransformer, Opcodes {


    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        if(className.equals("cr/launcher/RACUtils")){
            ClassReader classReader = new ClassReader(classfileBuffer);
            ClassNode classNode = new ClassNode();
            classReader.accept(classNode, 0);
            for(MethodNode methodNode : classNode.methods){
                if(!methodNode.name.equals("addRACLog")){
                    continue;
                }
                AbstractInsnNode first = methodNode.instructions.getLast();
                InsnList print = new InsnList();
                print.add(new FieldInsnNode(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;"));
                print.add(new VarInsnNode(ALOAD, 0));
                print.add(new MethodInsnNode(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false));

                methodNode.instructions.insertBefore(first, print);
                System.err.println("modified " + classNode.name+"."+methodNode.name+methodNode.desc);
            }
            ClassWriter classWriter = new ClassWriter(0);
            classNode.accept(classWriter);
            return classWriter.toByteArray();
        }
        /*
        if(className.equals("cr/references/CRReference")){
            ClassReader classReader = new ClassReader(classfileBuffer);
            ClassNode classNode = new ClassNode();
            classReader.accept(classNode, 0);
            for(MethodNode methodNode : classNode.methods){
                if(!methodNode.name.equals("<clinit>")){
                    continue;
                }
                AbstractInsnNode end = methodNode.instructions.getLast();
                //methodNode.instructions.remove(end.getPrevious().getPrevious().getPrevious());
                //methodNode.instructions.remove(end.getPrevious().getPrevious());
                //methodNode.instructions.remove(end.getPrevious());

            }
            ClassWriter classWriter = new ClassWriter(0);
            classNode.accept(classWriter);
            return classWriter.toByteArray();
        }*/
        return classfileBuffer;
    }
}
