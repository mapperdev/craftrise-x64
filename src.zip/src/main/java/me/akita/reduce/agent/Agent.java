package me.akita.reduce.agent;


import me.akita.reduce.agent.Transformer;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.util.Arrays;


public class Agent {

    public static void agentmain(String arguments, Instrumentation instrumentation){
        instrumentation.addTransformer(new Transformer(), true);
        Arrays.stream(instrumentation.getAllLoadedClasses()).forEach(loadedClass -> {
            if(loadedClass.getName().equals("cr.references.CRReference") || loadedClass.getName().equals("cr.launcher.RACUtils")){
                try {
                    instrumentation.retransformClasses(loadedClass);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        try{
            Class<?> clazz = Class.forName("cr.references.CRReference",     false, ClassLoader.getSystemClassLoader());
            Field field = clazz.getDeclaredField("STATE");
            field.setAccessible(true);
            field.setInt(null, 1);
            System.err.println(clazz.getName()+"."+field.getName() + " value changed!");
        }
        catch (Exception e){
            e.printStackTrace();
            System.exit(0);
        }
    }
}
