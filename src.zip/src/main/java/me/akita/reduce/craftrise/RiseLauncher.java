package me.akita.reduce.craftrise;/*

@Author https://github.com/akita0
2023

*/

import com.google.gson.Gson;
import com.sun.tools.attach.VirtualMachine;
import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.tree.ClassNode;
import me.akita.reduce.Main;
import me.akita.reduce.agent.Agent;
import me.akita.reduce.agent.Transformer;
import me.akita.reduce.launcher.KeyFinder;
import me.akita.reduce.launcher.SplashLoginObject;
import sun.jvmstat.monitor.MonitoredHost;
import sun.jvmstat.monitor.MonitoredVm;
import sun.jvmstat.monitor.MonitoredVmUtil;
import sun.jvmstat.monitor.VmIdentifier;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;

public class RiseLauncher {
    public String pass;
    public String username;
    public  KeyFinder keyFinder = new KeyFinder();
    public RiseLauncher(String user , String pass) {
        this.username = user;
        this.pass = pass;
        keyFinder.openConnection();
    }
    public void launchRise() throws Exception {
        File rise_path = new File("C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\");
        SplashLoginObject splash = null;
        {
            keyFinder.getSessions(username, pass);
            while (splash == null) {
                for (String message : keyFinder.messages) {
                    if (message.contains("SplashLogin")) {
                        System.out.println("SPLASH:" + message);
                        splash = new Gson().fromJson(message, SplashLoginObject.class);
                    }
                }
            }
        }
        System.out.println(String.format("Successfully created session for %s" , splash.getUsername()));
        System.out.println(String.format("Session: %s" , splash.getGlobalSessionHash()));
        System.out.println(String.format("Validator: %s" , splash.getKeyValidator()));
        CraftRiseSession craftRiseSession = new CraftRiseSession(rise_path, username, pass , splash.getGlobalSessionHash());
        CraftRiseSessionArg sessionArg = craftRiseSession.getCraftRiseSessionArg();
        sessionArg.encode("gameArguments");
        List<String> clientArgs = new ArrayList<>();
        clientArgs.add("C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\java\\jdk-x64\\bin\\javaw.exe");
        jvm:{
            clientArgs.add("-noverify");
            clientArgs.add("-XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump");
            clientArgs.add("-Xms1024M");
            clientArgs.add("-Xmx2048M");
            clientArgs.add("-Dlog4j2.formatMsgNoLookups=true");
            clientArgs.add("-Djava.net.preferIPv4Stack=true");
            clientArgs.add("-XX:+UseConcMarkSweepGC");
            clientArgs.add("-XX:-UseAdaptiveSizePolicy");
            clientArgs.add("-XX:+UseFastAccessorMethods");
            clientArgs.add("-Djava.library.path=C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\versions\\RiseClient_1.8.9\\" + nativeKey(new File("C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\versions\\RiseClient_1.8.9\\")));
        }
        java:{
            clientArgs.add("-cp");
            clientArgs.add("C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\versions\\RiseClient_1.8.9\\RiseClient_1.8.9.jar;C:\\Users\\akita\\AppData\\Roaming\\.craftrise\\libraries\\*");
        }
        main_class:{
            clientArgs.add("com.craftrise.client.main.MainLauncher");
        }
        client_args:{
            clientArgs.add(sessionArg.getGameArguments());
        }

        Process process = Runtime.getRuntime().exec(clientArgs.toArray(new String[0]), null, rise_path);
        OutputStream outputStream = process.getOutputStream();
        InputStream inputStream = process.getErrorStream();
        InputStream inputStream2 = process.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream2));
        BufferedReader bufferedErrorReader = new BufferedReader(new InputStreamReader(inputStream));
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    String string;
                    while ((string = bufferedReader.readLine()) != null){
                        System.out.println(string);
                        if(string.startsWith("rise:client:")){
                            String kk = string.split(":")[2];
                            String k = CraftRiseCrypto.d(CraftRiseCrypto.g(CraftRiseCrypto.f(kk, "1234758145215632")));
                            bufferedWriter.write("rise:launcher:"+k);
                            bufferedWriter.flush();
                            bufferedWriter.close();
                        }
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    String string;
                    while ((string = bufferedErrorReader.readLine()) != null){
                        System.err.println(string);
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
        TimeUnit.SECONDS.sleep(8);
        if(true){
            MonitoredHost monitoredHost = MonitoredHost.getMonitoredHost("localhost");
            for (int pid : monitoredHost.activeVms()){
                MonitoredVm monitoredVm = monitoredHost.getMonitoredVm(new VmIdentifier("//" + pid));

                String path = MonitoredVmUtil.mainClass(monitoredVm, true);
                boolean attachable = MonitoredVmUtil.isAttachable(monitoredVm);
                if(!path.contains("MainLauncher") || !attachable){
                    continue;
                }
                System.out.println(String.format("%s -- Attachable:%s", path, String.valueOf(attachable)));
                try{
                    try {
                        Field field = ClassLoader.class.getDeclaredField("sys_paths");
                        field.setAccessible(true);
                        field.set(null, null);
                    } catch(NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                        return;
                    }
                    try {
                        VirtualMachine virtualMachine = VirtualMachine.attach(String.valueOf(pid));
                        virtualMachine.loadAgent(new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath()).getAbsolutePath());
                        virtualMachine.detach();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        }
        new Thread(() -> {
            while(true)
            {
                System.out.println("RAC VERIFIED");
                keyFinder.printRacVerifier();
                try {
                    TimeUnit.SECONDS.sleep(15);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }
    public String nativeKey(File f) {
        return Arrays.stream(f.listFiles()).filter(fe -> fe.getName().contains("native")).findFirst().get().getName();
    }
    public static byte[] toByteArray(ClassNode classNode, int flags){
        ClassWriter classWriter = new ClassWriter(flags);
        classNode.accept(classWriter);
        return classWriter.toByteArray();
    }

    public static ClassNode toClassNode(Class<?> clazz){
        ClassNode classNode = new ClassNode();
        try{
            new ClassReader(clazz.getName()).accept(classNode, 0);
        }
        catch (Exception e){
            return null;
        }
        return classNode;
    }

    public static void buildAgentJar(File output) {
        try {
            Manifest manifest = new Manifest();
            manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
            manifest.getMainAttributes().put(new Attributes.Name("Agent-Class"), Agent.class.getName());
            manifest.getMainAttributes().putValue("Can-Retransform-Classes", "true");
            manifest.getMainAttributes().putValue("Can-Redifine-Classes", "true");
            manifest.getMainAttributes().putValue("Can-Set-Native-Prefix", "true");
            FileOutputStream fileOutputStream = new FileOutputStream(output);
            JarOutputStream jarOutputStream = new JarOutputStream(fileOutputStream, manifest);
            Map<String, byte[]> classMap = new HashMap<>();
            addClass(classMap, Agent.class);
            addClass(classMap, Transformer.class);
            for(Map.Entry<String, byte[]> entry : classMap.entrySet()){
                jarOutputStream.putNextEntry(new ZipEntry(entry.getKey()));
                jarOutputStream.write(entry.getValue());
                jarOutputStream.closeEntry();
            }
            jarOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addClass(Map<String, byte[]> map, Class<?> clazz){
        ClassNode classNode = toClassNode(clazz);
        if(classNode == null){
            return;
        }
        map.put(classNode.name+".class", toByteArray(classNode, 0));
    }

}