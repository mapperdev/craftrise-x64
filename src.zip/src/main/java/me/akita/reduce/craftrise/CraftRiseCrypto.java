package me.akita.reduce.craftrise;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.List;


public class CraftRiseCrypto {

    private static final String key = "2640023187059250";

    public static String g(String string) {
        if (string == null) {
            return string;
        }
        string = d(string);
        if (string == null) {
            return string;
        }
        string = d(string);
        if (string == null) {
            return null;
        }
        if (string.startsWith("3ebi2mclmAM7Ao2")) {
            if (string.endsWith("KweGTngiZOOj9d6")) {
                String string2 = string.substring(0, 15);
                String string3 = string.substring(string.length() - 15, string.length());
                if (string2.equals("3ebi2mclmAM7Ao2")) {
                    if (string3.equals("KweGTngiZOOj9d6")) {
                        String string4 = string.substring(15, string.length() - 15);
                        if (string4 == null) {
                            return string4;
                        }
                        return d(string4);
                    }
                }
                return string;
            }
        }
        return string;
    }

    public static String d(String str) {
        return new String(DatatypeConverter.parseBase64Binary(str), StandardCharsets.UTF_8);
    }
    public static String i(String str) {
        return i(str.getBytes(StandardCharsets.UTF_8));
    }

    public static String i(byte[] str) {
        return DatatypeConverter.printBase64Binary(str);
    }

    public static String f(String encryptedPass, String k){
        Serializable serializable;
        byte[] byArray = null;
        try {
            serializable = new SecretKeySpec(k.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(2, (Key)serializable);
            byArray = cipher.doFinal(DatatypeConverter.parseBase64Binary(encryptedPass));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return (new String(byArray));
    }

    public static String b(String string) {
        byte[] byArray = null;
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec("2650053489059452".getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(1, secretKeySpec);
            byArray = cipher.doFinal(string.getBytes());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return DatatypeConverter.printBase64Binary(byArray);
    }

    public static String f(String encryptedPass, String k, int mode){
        Serializable serializable;
        byte[] byArray = null;
        try {
            serializable = new SecretKeySpec(k.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(mode, (Key)serializable);
            byArray = cipher.doFinal(DatatypeConverter.parseBase64Binary(encryptedPass));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return (new String(byArray));
    }
    //41c63c8b-262b-43a7-beaf-768bc7f6e9f0###DARELRISE###iMayori
    public static String c(String pt) {
        String string = pt;
        byte[] byArray = null;
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec("2650053489059452".getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(2, secretKeySpec);
            byArray = cipher.doFinal(DatatypeConverter.parseBase64Binary((String)string));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return new String(byArray);
    }
    public static String encrypt(String pt) {
        String string = pt;
        byte[] byArray = null;
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec("2650053489059452".getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(1, secretKeySpec);
            byArray = cipher.doFinal(string.getBytes());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return DatatypeConverter.printBase64Binary(byArray);
    }
    public static String a_hash(String string, String string2) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(string2);
            byte[] byArray = messageDigest.digest(string.getBytes());
            StringBuilder stringBuffer = new StringBuilder();
            int n3 = 0;
            if (n3 < byArray.length) {
                stringBuffer.append(Integer.toHexString(byArray[n3] & 0xFF | 0x100).substring(1, 3));
                ++n3;
            }
            return stringBuffer.toString();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String b_md5_hash(String string) {
        return a_hash(string, "MD5");
    }


}
