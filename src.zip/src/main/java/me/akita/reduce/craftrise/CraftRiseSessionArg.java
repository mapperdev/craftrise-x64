package me.akita.reduce.craftrise;

import java.lang.reflect.Field;


public class CraftRiseSessionArg {

    private String clientFolderPath;
    private String javaNativesPath;
    private String javaPath;
    private String jvmDllPath;
    private String javaRam;
    private String gameArguments;
    private String javaLibrariesPath;
    private String directory;
    private String javaType;

    public void encode()throws IllegalAccessException {
        for(Field field : getClass().getDeclaredFields()){
            Object o = field.get(this);
            if(o == null){
                continue;
            }
            String content = (String) o;
            field.set(this, CraftRiseCrypto.i(content));
        }
    }

    public void encode(String key)throws IllegalAccessException, NoSuchFieldException{
        Field field = getClass().getDeclaredField(key);
        if(field == null){
            return;
        }
        Object o = field.get(this);
        if(o == null){
            return;
        }
        String content = (String) o;
        field.set(this, CraftRiseCrypto.i(content));
    }

    public void decode(String key)throws IllegalAccessException, NoSuchFieldException{
        Field field = getClass().getDeclaredField(key);
        if(field == null){
            return;
        }
        Object o = field.get(this);
        if(o == null){
            return;
        }
        String content = (String) o;
        field.set(this, CraftRiseCrypto.d(content));
    }

    public void decode()throws IllegalAccessException {
        for(Field field : getClass().getDeclaredFields()){
            Object o = field.get(this);
            if(o == null){
                continue;
            }
            String content = (String) o;
            field.set(this, CraftRiseCrypto.d(content));
        }
    }

    public String getClientFolderPath() {
        return clientFolderPath;
    }

    public String getJavaNativesPath() {
        return javaNativesPath;
    }

    public String getJavaPath() {
        return javaPath;
    }

    public String getJvmDllPath() {
        return jvmDllPath;
    }

    public String getJavaRam() {
        return javaRam;
    }

    public String getGameArguments() {
        return gameArguments;
    }

    public String getJavaLibrariesPath() {
        return javaLibrariesPath;
    }

    public String getDirectory() {
        return directory;
    }

    public String getJavaType() {
        return javaType;
    }

    public void setClientFolderPath(String clientFolderPath) {
        this.clientFolderPath = clientFolderPath;
    }

    public void setJavaNativesPath(String javaNativesPath) {
        this.javaNativesPath = javaNativesPath;
    }

    public void setJavaPath(String javaPath) {
        this.javaPath = javaPath;
    }

    public void setJvmDllPath(String jvmDllPath) {
        this.jvmDllPath = jvmDllPath;
    }

    public void setJavaRam(String javaRam) {
        this.javaRam = javaRam;
    }

    public void setGameArguments(String gameArguments) {
        this.gameArguments = gameArguments;
    }

    public void setJavaLibrariesPath(String javaLibrariesPath) {
        this.javaLibrariesPath = javaLibrariesPath;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public void setJavaType(String javaType) {
        this.javaType = javaType;
    }
}
