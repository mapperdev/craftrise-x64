package me.akita.reduce.craftrise;


public class CraftRiseGameArgBuilder {

    private final StringBuilder builder = new StringBuilder();

    public CraftRiseGameArgBuilder put(String key, String value){
        builder.append("--").append(key).append(" ").append(value).append(" ");
        return this;
    }

    public CraftRiseGameArgBuilder add(String s){
        builder.append(s).append(" ");
        return this;
    }

    public String build(){
        String b = builder.toString().replace(" ", "###");
        return b.substring(0, b.length()-"###".length());
    }

}
