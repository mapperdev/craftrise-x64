package me.akita.reduce.craftrise;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.UUID;


public class CraftRiseSession {

    private File craftrise_path;
    private CraftRiseSessionArg craftRiseSessionArg;

    public CraftRiseSession(File craftrise_path, String username, String password , String hash) {
        this.craftrise_path = craftrise_path;
        this.craftRiseSessionArg = buildArg(username, password , hash);
    }

    private final CraftRiseSessionArg buildArg(String username, String password , String sessionHash){
        CraftRiseSessionArg sessionArg = new CraftRiseSessionArg();
        gameArguments:{
            CraftRiseGameArgBuilder builder = new CraftRiseGameArgBuilder();
            {
                builder.put("username", CraftRiseCrypto.b(String.format("%s###%s###%s", username, String.valueOf(System.currentTimeMillis()), "minecraft.jar")));
                builder.put("version", "RiseClient_1.8.9");
                builder.put("gameDir", craftrise_path.getAbsolutePath());
                builder.put("assetsDir", new File(craftrise_path, "assets").getAbsolutePath());
                builder.put("assetIndex", "1.8");
                builder.put("uuid", UUID.nameUUIDFromBytes(String.format("OfflinePlayer:%s", username).getBytes(StandardCharsets.UTF_8)).toString().replace("-", ""));
                builder.put("accessToken", "0000000000000");
                builder.put("launcherKeys", "nGFwQClmnzo5kargZlW9Ztbr4/kkveuXkEo8aZxBhSNt8+y+E7A4zsL9ho9UpOeGZVJ5AKfOTnXke5+oQYUdilIqyMfjXGa7ow49nyTNcuo="); // ???????????????????
                builder.put("userType", "legacy");
                builder.add("--height=480");
                builder.add("--width=854");
                builder.put("server", "bypass.akeno.wtf");
                builder.put("port", "25565");
                builder.put("password", CraftRiseCrypto.i(password));
                builder.put("launcherKey", "I_AM_RISELAUNCHER_NEW");
                builder.put("launcherLang", "0");
                builder.put("sessionHash" , sessionHash);
                builder.put("LJavaVersion", System.getProperty("java.version"));
                builder.put("Lpid", "0000");
                builder.put("launcherSecHash", "26Ffcm3VhyUNP8QrI03Jp3jyrRN3lAZpyZXBRqFo6VRJSQmjXU6qaDlFYZRVVhT0");
                builder.put("mAd", CraftRiseCrypto.i(CraftRiseCrypto.b(CraftRiseCrypto.b(CraftRiseCrypto.i(String.format("%s###%s###%s", username, "2ba8698b79439589fdd2b0f7218d8b07", String.valueOf(System.currentTimeMillis())))))));
            }
            sessionArg.setGameArguments(builder.build());
        }
        return sessionArg;
    }

    public CraftRiseSessionArg getCraftRiseSessionArg() {
        return craftRiseSessionArg;
    }
}
